# app.py
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv
from sqlalchemy import text
import pickle
import numpy as np
import os
from datetime import datetime
from werkzeug.utils import secure_filename
import pandas as pd
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'change-me-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///database.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Fix postgres:// → postgresql://
if app.config['SQLALCHEMY_DATABASE_URI'].startswith("postgres://"):
    app.config['SQLALCHEMY_DATABASE_URI'] = app.config['SQLALCHEMY_DATABASE_URI'].replace("postgres://", "postgresql://", 1)

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB max
ALLOWED_EXTENSIONS = {'csv'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Global variable to hold current dataset
current_dataset = None
current_dataset_name = "No file uploaded yet"

# ====================
# Flask-Login User Class (Minimal – no db.Model!)
# ====================
class User(UserMixin):
    def __init__(self, id, username, email):
        self.id = id
        self.username = username
        self.email = email

    def get_id(self):
        return str(self.id)

@login_manager.user_loader
def load_user(user_id):
    result = db.session.execute(
        text("SELECT id, username, email FROM user WHERE id = :id"),
        {"id": user_id}
    ).fetchone()
    if result:
        return User(result[0], result[1], result[2])
    return None

# Load ML Models
with open('model/random_forest_model.pkl', 'rb') as f:
    rf_model = pickle.load(f)
with open('model/xgb_classifier.pkl', 'rb') as f:
    xgb_model = pickle.load(f)

# Load label encoders (YOU MUST HAVE THIS FILE FROM TRAINING!)
with open('model/label_encoders.pkl', 'rb') as f:
    label_encoders = pickle.load(f)

import shap
import matplotlib
matplotlib.use('Agg')            # ← THIS FIXES THE TKINTER ERROR FOREVER
import matplotlib.pyplot as plt
import io
import base64
from io import StringIO

# Load explainer once (outside route for speed)
explainer_rf = shap.TreeExplainer(rf_model)

feature_names = [
    "CO AQI Value", "CO AQI Category",
    "Ozone AQI Value", "Ozone AQI Category",
    "NO₂ AQI Value", "NO₂ AQI Category",
    "PM2.5 AQI Value", "PM2.5 AQI Category",
    "Area Type (Rural=1, Urban=2)"]

# ======================
# Routes – All using RAW SQL
# ======================

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        # Check if user exists
        exists = db.session.execute(
            text("SELECT 1 FROM user WHERE username = :u OR email = :e"),
            {"u": username, "e": email}
        ).fetchone()

        if exists:
            flash('Username or email already taken')
            return redirect(url_for('register'))

        hashed = generate_password_hash(password, method='pbkdf2:sha256')
        db.session.execute(
            text("INSERT INTO user (username, email, password) VALUES (:u, :e, :p)"),
            {"u": username, "e": email, "p": hashed}
        )
        db.session.commit()
        flash('Registration successful! Please login.')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        identifier = request.form['username']  # Could be username or email
        password = request.form['password']

        # Search by username OR email
        user_row = db.session.execute(
            text("SELECT id, username, email, password FROM user WHERE username = :id OR email = :id"),
            {"id": identifier}
        ).fetchone()

        if user_row and check_password_hash(user_row[3], password):
            user_obj = User(user_row[0], user_row[1], user_row[2])
            login_user(user_obj)
            flash('Login successful!')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username/email or password')

    return render_template('login.html')
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')
# ==================== UPLOAD ROUTE ====================
@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload_dataset():
    global current_dataset, current_dataset_name

    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file selected')
            return redirect(request.url)
        
        file = request.files['file']
        if file.filename == '':
            flash('No file selected')
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            try:
                df = pd.read_csv(filepath)
                current_dataset = df
                current_dataset_name = filename
                flash(f'Success! Loaded {len(df):,} rows from "{filename}"')
                return redirect(url_for('view_data'))
            except Exception as e:
                flash(f'Error reading CSV: {str(e)}')
        else:
            flash('Only .csv files allowed!')
    
    return render_template('upload.html', current_file=current_dataset_name)

# ==================== VIEW DATA (NOW USES UPLOADED FILE) ====================
@app.route('/view_data')
@login_required
def view_data():
    global current_dataset

    if current_dataset is None:
        # Show upload prompt if no data
        return render_template('view_data_empty.html')

    # Define your exact columns
    cols = [
        'City', 'Country', 'Country', 'Area_Type',
        'AQI Value', 'AQI Category',
        'CO AQI Value', 'CO AQI Category',
        'Ozone AQI Value', 'Ozone AQI Category',
        'NO2 AQI Value', 'NO2 AQI Category',
        'PM2.5 AQI Value', 'PM2.5 AQI Category'
    ]

    # Safely select columns that exist
    available = [c for c in cols if c in current_dataset.columns]
    data = current_dataset[available].head(500).to_dict('records')  # limit for speed

    return render_template('view_data.html', data=data, total_rows=len(current_dataset))

@app.route('/model')
@login_required
def model():
    model_info = {
        "Random Forest Regressor": {"type": "Regression", "accuracy": "R² = 0.94"},
        "XGBoost Classifier": {"type": "Classification", "accuracy": "96.2%"}
    }
    return render_template('model.html', models=model_info)

@app.route('/predict', methods=['GET', 'POST'])
@login_required
def predict():
    prediction = None
    plots = {'force': None, 'waterfall': None, 'dependence': None}

    if request.method == 'POST':
        try:
            # === GET VALUES FROM FORM ===
            co_val = float(request.form['co_value'])
            ozone_val = float(request.form['ozone_value'])
            no2_val = float(request.form['no2_value'])
            pm25_val = float(request.form['pm25_value'])
            area_type = request.form['area_type']

            # === ENCODE CATEGORIES ===
            cat_map = {'Good': 0, 'Moderate': 1, 'Unhealthy for Sensitive Groups': 2,
                       'Unhealthy': 3, 'Very Unhealthy': 4, 'Hazardous': 5}
            area_map = {'Rural': 1, 'Urban': 2}

            # === BUILD FEATURE ARRAY ===
            features = np.array([[
                co_val, cat_map[request.form['co_cat']],
                ozone_val, cat_map[request.form['ozone_cat']],
                no2_val, cat_map[request.form['no2_cat']],
                pm25_val, cat_map[request.form['pm25_cat']],
                area_map[area_type]
            ]])

            # === MAKE PREDICTIONS ===
            predicted_aqi = round(rf_model.predict(features)[0], 2)
            predicted_category = ['Good', 'Moderate', 'Unhealthy for Sensitive Groups',
                                  'Unhealthy', 'Very Unhealthy', 'Hazardous'][
                int(xgb_model.predict(features)[0])
            ]

            # === HEALTH IMPACT TEXT ===
            health_messages = {
                'Good': 'Air quality is satisfactory.',
                'Moderate': 'Acceptable air quality. Sensitive people should limit outdoor exertion.',
                'Unhealthy for Sensitive Groups': 'Sensitive groups may experience health effects.',
                'Unhealthy': 'Everyone may begin to experience health effects.',
                'Very Unhealthy': 'Health warnings of emergency conditions.',
                'Hazardous': 'Health alert: everyone may experience serious effects.'
            }

            # === SHAP EXPLANATIONS ===
            shap_values = explainer_rf.shap_values(features)

            # 1. Force Plot (Interactive)
            shap.initjs()
            force = shap.force_plot(
                explainer_rf.expected_value,
                shap_values[0],
                features[0],
                feature_names=feature_names,
                show=False,
                matplotlib=False
            )
            html_buffer = StringIO()
            shap.save_html(html_buffer, force)
            plots['force'] = html_buffer.getvalue()

            # 2. Waterfall Plot
            plt.figure(figsize=(12, 8))
            shap.waterfall_plot(
                shap.Explanation(values=shap_values[0],
                                 base_values=explainer_rf.expected_value,
                                 data=features[0],
                                 feature_names=feature_names),
                max_display=10,
                show=False
            )
            buf = io.BytesIO()
            plt.savefig(buf, format='png', dpi=150, bbox_inches='tight', facecolor='#0f172a')
            buf.seek(0)
            plots['waterfall'] = base64.b64encode(buf.getvalue()).decode()
            plt.close()

            # 3. PM2.5 Dependence Plot
            try:
                bg_data = pd.DataFrame(np.tile(features[0], (100, 1)), columns=feature_names)
                shap_bg = explainer_rf.shap_values(bg_data)

                plt.figure(figsize=(10, 6))
                shap.dependence_plot("PM.5 AQI Value", shap_bg, bg_data,
                                     feature_names=feature_names, show=False)
                buf = io.BytesIO()
                plt.savefig(buf, format='png', dpi=150, bbox_inches='tight', facecolor='#0f172a')
                buf.seek(0)
                plots['dependence'] = base64.b64encode(buf.getvalue()).decode()
                plt.close()
            except:
                pass

            # === SAVE TO DATABASE ===
            try:
                db.session.execute(
                    text("""INSERT INTO prediction_history 
                            (user_id, co_aqi, ozone_aqi, no2_aqi, pm25_aqi,
                             predicted_aqi, predicted_category, timestamp)
                            VALUES (:uid, :co, :ozone, :no2, :pm25, :aqi, :cat, :ts)"""),
                    {"uid": current_user.id,
                     "co": co_val, "ozone": ozone_val, "no2": no2_val,
                     "pm25": pm25_val, "aqi": predicted_aqi,
                     "cat": predicted_category, "ts": datetime.utcnow()}
                )
                db.session.commit()
            except Exception as e:
                db.session.rollback()

            # === SEND ONLY REAL DATA TO TEMPLATE ===
            prediction = {
                "aqi": predicted_aqi,
                "category": predicted_category,
                "health_impact": health_messages[predicted_category]
            }

        except Exception as e:
            flash(f"Error: {str(e)}", "danger")

    # This keeps form values after submit
    return render_template(
        'prediction.html',
        prediction=prediction,
        plots=plots,
        form_data=request.form
    )

def get_aqi_level(aqi):
    if aqi <= 50: return "Good"
    elif aqi <= 100: return "Moderate"
    elif aqi <= 150: return "Unhealthy for Sensitive Groups"
    elif aqi <= 200: return "Unhealthy"
    elif aqi <= 300: return "Very Unhealthy"
    else: return "Hazardous"

@app.route('/history')
@login_required
def history():
    user_result = db.session.execute(
        text("SELECT id FROM user WHERE username = :u"),
        {"u": current_user.username}
    ).fetchone()

    if not user_result:
        flash("User not found!", "danger")
        return redirect(url_for('dashboard'))

    user_id = user_result[0]

    rows = db.session.execute(
        text("""SELECT timestamp, co_aqi, ozone_aqi, no2_aqi, pm25_aqi,
                       predicted_aqi, predicted_category
                FROM prediction_history
                WHERE user_id = :uid
                ORDER BY timestamp DESC"""),
        {"uid": user_id}
    ).fetchall()

    history = []
    for row in rows:
        # THIS IS THE FIX: Always convert timestamp to datetime object
        ts = row[0]
        if isinstance(ts, str):
            try:
                ts = datetime.fromisoformat(ts.replace('Z', '+00:00'))
            except:
                ts = datetime.utcnow()
        elif ts is None:
            ts = datetime.utcnow()

        history.append({
            "timestamp": ts,           # ← now always a real datetime object
            "co": row[1] or 0,
            "ozone": row[2] or 0,
            "no2": row[3] or 0,
            "pm25": row[4] or 0,
            "aqi": round(row[5] or 0, 2) if row[5]  else 0,
            "category": row[6] or "Unknown"
        })

    return render_template('history.html', history=history)

@app.route('/models')
@login_required
def models():
    model_info = {
        "Random Forest Regressor": {
            "type": "Regression",
            "target": "AQI Value (Numeric)",
            "accuracy": "R² = 0.94 (trained on rural dataset)",
            "description": "Predicts continuous AQI value using CO, Ozone, NO2, PM2.5"
        },
        "XGBoost Classifier": {
            "type": "Classification",
            "target": "AQI Category",
            "accuracy": "Accuracy = 96.2%",
            "classes": ['Good', 'Moderate', 'Unhealthy for Sensitive Groups', 'Unhealthy', 'Very Unhealthy', 'Hazardous'],
            "description": "Classifies air quality into health impact categories"
        }
    }
    return render_template('models.html', models=model_info)

def get_aqi_level(aqi):
    if aqi <= 50: return "Good"
    elif aqi <= 100: return "Moderate"
    elif aqi <= 150: return "Unhealthy for Sensitive Groups"
    elif aqi <= 200: return "Unhealthy"
    elif aqi <= 300: return "Very Unhealthy"
    else: return "Hazardous"

from datetime import datetime

# Add this function to make {{ now() }} work in templates
@app.context_processor
def inject_now():
    return {'now': datetime.utcnow}
@app.template_filter('strftime')
def _jinja2_filter_strftime(date, fmt):
    return date.strftime(fmt)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)