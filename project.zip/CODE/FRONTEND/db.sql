-- Create users table
CREATE TABLE user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL
);

-- Create predictions history table
CREATE TABLE prediction_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    co_aqi REAL,
    ozone_aqi REAL,
    no2_aqi REAL,
    pm25_aqi REAL,
    predicted_aqi REAL,
    predicted_category TEXT,
    FOREIGN KEY (user_id) REFERENCES user (id)
);